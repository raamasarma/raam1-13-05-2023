package com.raithanna.dairy.RaithannaDairy.models;

public class DownloadSuperBean {
    public DownloadSuperBean(){

    }
}
